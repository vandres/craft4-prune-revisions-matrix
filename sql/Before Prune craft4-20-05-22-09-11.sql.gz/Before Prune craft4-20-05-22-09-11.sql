# ************************************************************
# Sequel Ace SQL dump
# Version 20033
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.3.27-MariaDB-1:10.3.27+maria~focal)
# Datenbank: craft4
# Verarbeitungszeit: 2022-05-20 06:11:57 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Tabellen-Dump addresses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `addresses`;

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_eyflsyjmohtskzaimddsovtpbsvynpnjtwtq` (`ownerId`),
  CONSTRAINT `fk_eyflsyjmohtskzaimddsovtpbsvynpnjtwtq` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wxvdnnksxubtvtrhzrmiqomqhsnxhggdwylb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump announcements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `announcements`;

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tpkzieqapnbgslaucvlfzfzayfkeiqkkiztv` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_kbruxyrfttbsbmfohchlhnlccpzblbdmuzaq` (`dateRead`),
  KEY `fk_adawhjqdsafwefivmwxrmrxrliuxnnhjchol` (`pluginId`),
  CONSTRAINT `fk_adawhjqdsafwefivmwxrmrxrliuxnnhjchol` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwpgyghaqstgrvjcknrdustqyidvvibdvrwp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump assetindexdata
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assetindexdata`;

CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nvlnptvrfqymgxhcsexrcywfqvcxcxqiokml` (`sessionId`,`volumeId`),
  KEY `idx_cnzmkbcamextwfaqgvspjmnodkebppleodds` (`volumeId`),
  CONSTRAINT `fk_ewuumghmdyrcmnymbcdonwfrazoccldxkrit` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_huereyueazftpqsbxwydeqgcuzzxtbukszrb` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump assetindexingsessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assetindexingsessions`;

CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump assets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assets`;

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gedlqkupfxzyyjpubfmioqnpndxjpuyybyws` (`filename`,`folderId`),
  KEY `idx_qxkfjiwyprjfetpbnauvjhnelmoqqzqfmfxl` (`folderId`),
  KEY `idx_vahrjajspsavqtlibyhnexmrztwurnykvabg` (`volumeId`),
  KEY `fk_nqbqizrdxtztgmqxsrarduoszxbwqzsnnuud` (`uploaderId`),
  CONSTRAINT `fk_dgmeshpwwvyahcjuzjukobowalmztykkfpvg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_icfhdtarhavmkpmzcabwkmctvepfalwvdigl` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nqbqizrdxtztgmqxsrarduoszxbwqzsnnuud` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vdupjkgilehxqgdrulsthigzerpzjxvkwevn` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cuomdkrxrttxnjfdjdaqcgwcnezkyqrlkfkt` (`groupId`),
  KEY `fk_aioxsjsvhvfmgeqetakyqfsfqtatuuttveoe` (`parentId`),
  CONSTRAINT `fk_aioxsjsvhvfmgeqetakyqfsfqtatuuttveoe` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_prfzjqbunqhdfaudoekctjkxgseqyroqpvkb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qsovcrrcnlrogasezxndsctlmsdzzdbwohum` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump categorygroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categorygroups`;

CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yptvnxijialqjnjomovyvoevhfyaawpbhiqb` (`name`),
  KEY `idx_fvzunbjmyonldalwpqahikrnenexpnxxuamv` (`handle`),
  KEY `idx_vmlefxtfgimtshxxxatzljukuwwlzvmeaivu` (`structureId`),
  KEY `idx_kkjkcitclmzsagbidfgnhzrxavkqjmgsaniz` (`fieldLayoutId`),
  KEY `idx_qlpjqavzqskwztjevrchljchwfvryqdiyqcd` (`dateDeleted`),
  CONSTRAINT `fk_ndpkeqybqxxcgzyzzhuocnbsfastjtwkzqjh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xwldvpgdjnutjxxcevbuyvhunawrwshadgip` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump categorygroups_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categorygroups_sites`;

CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hbqapsjlvlsrerwqlelpgqfoaplzybtrvhif` (`groupId`,`siteId`),
  KEY `idx_awhdcdyytxdyvsrqgenzdszqjxvrvyontynz` (`siteId`),
  CONSTRAINT `fk_duvxearuelevvffwdzelikxfngsaiuydddpa` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nqyconrbyrflrtqhkcutbtzsndmhnxkucvxu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump changedattributes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `changedattributes`;

CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ykpumpzyfnckdvnfuanupcrljiyqckijkxkb` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_trdepvrmibtstuzhvptjpxbeiiuttswqyooz` (`siteId`),
  KEY `fk_jlcnypyqgebmaqogddohyjpqaqjauphyoxpr` (`userId`),
  CONSTRAINT `fk_bqgnkpgabnsqktimundkeduucisyamrsscqh` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jlcnypyqgebmaqogddohyjpqaqjauphyoxpr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_trdepvrmibtstuzhvptjpxbeiiuttswqyooz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;

INSERT INTO `changedattributes` (`elementId`, `siteId`, `attribute`, `dateUpdated`, `propagated`, `userId`)
VALUES
	(2,1,'uri','2022-05-20 06:11:16',0,1);

/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump changedfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `changedfields`;

CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_lblwbgxmtlntvbaoniwzcnycosmmteubirbt` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ffobbdshynmxutpljuhallxvjizlfzbqdbsm` (`siteId`),
  KEY `fk_hvjhxrzxmaucziwwthkeglojzqieeittnkjm` (`fieldId`),
  KEY `fk_havfwfthdfjvhottpttxbtwiymxdcjylkoqy` (`userId`),
  CONSTRAINT `fk_ffobbdshynmxutpljuhallxvjizlfzbqdbsm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_havfwfthdfjvhottpttxbtwiymxdcjylkoqy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_hvjhxrzxmaucziwwthkeglojzqieeittnkjm` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qmhwdrwvspwczoaxanmpnasdhxgegbrbwziq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;

INSERT INTO `changedfields` (`elementId`, `siteId`, `fieldId`, `dateUpdated`, `propagated`, `userId`)
VALUES
	(2,1,1,'2022-05-20 06:11:40',0,1);

/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `content`;

CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mnwboxfmgwhvjgfhxbsceybtcstvsozmhkbu` (`elementId`,`siteId`),
  KEY `idx_tbmembdcevazoddgflnwfhaprbdrikvpbgxm` (`siteId`),
  KEY `idx_sqoszwpwmeuggjqonbeyssybhljbkgervvnt` (`title`),
  CONSTRAINT `fk_dekuwtrvwqujwaluxhxiiabkzoewqpllrcfp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tjsmhxtsxszcolvxtlkishkbtedmtwekenji` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;

INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,NULL,'2022-05-20 05:57:30','2022-05-20 05:57:30','c790bd25-3fc8-4de6-9387-290516fcdc05'),
	(2,2,1,'Home','2022-05-20 06:08:07','2022-05-20 06:11:45','c92646d7-fdf2-4297-9611-9655c2a8acfb'),
	(3,3,1,'Home','2022-05-20 06:08:07','2022-05-20 06:08:07','710a06de-5f29-47ff-843d-89060973914b'),
	(4,2,2,'Home','2022-05-20 06:11:16','2022-05-20 06:11:45','442fc197-3dac-412e-8848-32296c569a42'),
	(5,4,1,'Home','2022-05-20 06:11:16','2022-05-20 06:11:16','932db0f2-9c42-4c62-bc05-1cfa2882eee6'),
	(6,4,2,'Home','2022-05-20 06:11:16','2022-05-20 06:11:16','78b546ed-1ae6-411c-bad7-1d9dd3c88c2e'),
	(7,5,1,'Home','2022-05-20 06:11:25','2022-05-20 06:11:25','e81971b6-ed94-4e79-a597-6f21f7055b3a'),
	(8,5,2,'Home','2022-05-20 06:11:25','2022-05-20 06:11:25','ec992673-6a90-4271-80f7-68249277aa96'),
	(11,20,1,'Home','2022-05-20 06:11:40','2022-05-20 06:11:40','bdda4dc6-4b8d-4e80-bf90-82c3fc13d7fd'),
	(12,20,2,'Home','2022-05-20 06:11:40','2022-05-20 06:11:40','158b4d73-ff05-427b-9d4a-c3a1fd362bcd'),
	(13,23,1,'Home','2022-05-20 06:11:45','2022-05-20 06:11:45','33ae3032-078d-4a52-9eb5-46a80b9b28dc'),
	(14,23,2,'Home','2022-05-20 06:11:45','2022-05-20 06:11:45','a0a83306-4594-496d-95a3-e591d87c585d');

/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump craftidtokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craftidtokens`;

CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_fxbymymtbxkxdnpblxunqvzbxguvotohvwzg` (`userId`),
  CONSTRAINT `fk_fxbymymtbxkxdnpblxunqvzbxguvotohvwzg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump deprecationerrors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `deprecationerrors`;

CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_twxcrpzezrkkxscsbdcsnpaisyxjqmykmuss` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump drafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `drafts`;

CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_lvvzcfrljlpnfvuxlldzvprbwkzfcqpfulvx` (`creatorId`,`provisional`),
  KEY `idx_evmsbuftrmpvepfcbzcjqjzcrhjvgvluygvu` (`saved`),
  KEY `fk_jyxxugpamhmgubauxlqkqejpdnvfcybgtxnb` (`canonicalId`),
  CONSTRAINT `fk_jyxxugpamhmgubauxlqkqejpdnvfcybgtxnb` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tiewvymjljdufxjfiqqpbjvyzjzrjotgtdey` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump elements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `elements`;

CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pryjimujqvzedufkygupglvsxttearqslgsb` (`dateDeleted`),
  KEY `idx_ggzqwigijdxkbqnieugkhehzborroivxhpvb` (`fieldLayoutId`),
  KEY `idx_wwwllsuonjgivgixjctfoyrngclnstxbmklr` (`type`),
  KEY `idx_ioxiyoptxetqsbpjbdwgipsmzaowtjsdoyfx` (`enabled`),
  KEY `idx_lbnupltkxqwgqmacvbwxjtwmyqkqbntktewo` (`archived`,`dateCreated`),
  KEY `idx_pqywxmaxzzjubukdeizroltukbpehyapxcos` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_ihysdlzmidzgbrbueybjcmopflypywgpurmu` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_dtilyitlebcwcvazwlsjvqsazyzlydtmewip` (`canonicalId`),
  KEY `fk_rrvvvsumxkeonhaohloutzkioioubwsgnsxx` (`draftId`),
  KEY `fk_crjmzxfcnsmhykgopjdcwitrscggvsdjimhk` (`revisionId`),
  CONSTRAINT `fk_akhdyfaygdtmwxxydnsbmmwywaummcwyuzlk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_crjmzxfcnsmhykgopjdcwitrscggvsdjimhk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dtilyitlebcwcvazwlsjvqsazyzlydtmewip` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rrvvvsumxkeonhaohloutzkioioubwsgnsxx` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;

INSERT INTO `elements` (`id`, `canonicalId`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateLastMerged`, `dateDeleted`, `uid`)
VALUES
	(1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2022-05-20 05:57:30','2022-05-20 05:57:30',NULL,NULL,'a0c5cbd8-2673-419f-9a79-8bc7f464e184'),
	(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2022-05-20 06:08:07','2022-05-20 06:11:45',NULL,NULL,'fc10faac-20c5-413c-8b2a-719c45b0a7fd'),
	(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2022-05-20 06:08:07','2022-05-20 06:08:07',NULL,NULL,'c0c487db-d567-4b7b-b4ff-8b8a032c7191'),
	(4,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2022-05-20 06:11:16','2022-05-20 06:11:16',NULL,NULL,'497aa1de-fbf0-43df-9038-2bedcc00d7f0'),
	(5,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2022-05-20 06:11:25','2022-05-20 06:11:25',NULL,NULL,'a59e62bd-432e-471b-ba2a-79b48df6293d'),
	(7,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:32','2022-05-20 06:11:32',NULL,'2022-05-20 06:11:35','c36b59af-3a86-4f2e-8657-ca0cd5021de4'),
	(8,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:35','2022-05-20 06:11:35',NULL,'2022-05-20 06:11:36','f8998ccd-76fc-49fa-bd55-e401218435a3'),
	(9,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:36','2022-05-20 06:11:36',NULL,'2022-05-20 06:11:37','fd9ff076-1219-45ea-8e40-19290128ccdb'),
	(10,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:36','2022-05-20 06:11:36',NULL,'2022-05-20 06:11:38','0d10e022-7b69-4a39-a2a3-94ebd77fa821'),
	(11,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:37','2022-05-20 06:11:37',NULL,'2022-05-20 06:11:38','f7db2a25-1e72-42aa-abfc-05624578d4d0'),
	(12,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:38','2022-05-20 06:11:38',NULL,'2022-05-20 06:11:39','1e13a7ec-7a9a-4fa9-8b6c-ff595151afdb'),
	(13,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:38','2022-05-20 06:11:38',NULL,'2022-05-20 06:11:39','5c7375b5-5655-4312-a8dd-96aeb6f69d97'),
	(14,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:39','2022-05-20 06:11:39',NULL,'2022-05-20 06:11:40','3f58ceed-7c64-4117-adfb-ca724b69ef97'),
	(15,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:39','2022-05-20 06:11:39',NULL,'2022-05-20 06:11:40','76cc3316-6db5-446e-84f2-3ac58471c46a'),
	(18,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:40','2022-05-20 06:11:40',NULL,NULL,'3a0e4990-5054-4de8-8023-5cac91277ea4'),
	(19,NULL,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:40','2022-05-20 06:11:40',NULL,NULL,'1330063e-c997-4364-8991-35b38a133057'),
	(20,2,NULL,4,1,'craft\\elements\\Entry',1,0,'2022-05-20 06:11:40','2022-05-20 06:11:40',NULL,NULL,'33125efb-33d1-4342-ac66-59859878ec65'),
	(21,18,NULL,5,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:40','2022-05-20 06:11:40',NULL,NULL,'6b1168de-a7f6-48e4-8088-9112d7144c02'),
	(22,19,NULL,6,2,'craft\\elements\\MatrixBlock',1,0,'2022-05-20 06:11:40','2022-05-20 06:11:40',NULL,NULL,'11446ebb-6b21-46fa-83cb-c8fe91024b75'),
	(23,2,NULL,7,1,'craft\\elements\\Entry',1,0,'2022-05-20 06:11:45','2022-05-20 06:11:45',NULL,NULL,'f69783ab-b534-4a18-9fb0-bb502c5705a6');

/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump elements_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `elements_sites`;

CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_epazifwjwawcngizznnnzvmzfrlyubpsfwbx` (`elementId`,`siteId`),
  KEY `idx_zrebkuoqlecaqyvshgnftutocjrkukyvxiri` (`siteId`),
  KEY `idx_aascilnvxkzjozukmnuzedbeefufsrpbazxc` (`slug`,`siteId`),
  KEY `idx_quxeiqavhueytxwzryvfmkhofgkawcxozzji` (`enabled`),
  KEY `idx_xuvvjxbgxjykkpcwpzykenoqkmauobgjsdmj` (`uri`,`siteId`),
  CONSTRAINT `fk_kkesiweloozywhowtazaomirrdgxqiggsgry` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qyhwdhmoxbqwlftfllxbedwtuevudoxrnhws` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;

INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,NULL,NULL,1,'2022-05-20 05:57:30','2022-05-20 05:57:30','323091e8-c52e-4e3f-bccf-6dad4ed1a114'),
	(2,2,1,'home',NULL,1,'2022-05-20 06:08:07','2022-05-20 06:11:16','3117c099-e8ec-48c1-b16b-1fe3ae70b239'),
	(3,3,1,'home','home',1,'2022-05-20 06:08:07','2022-05-20 06:08:07','054fbd7e-c1e1-4c11-b07e-a83e40a2c1bd'),
	(4,2,2,'home',NULL,1,'2022-05-20 06:11:16','2022-05-20 06:11:16','c57cfed1-ce09-4fe1-8a29-c64b0fc9a1d3'),
	(5,4,1,'home',NULL,1,'2022-05-20 06:11:16','2022-05-20 06:11:16','ebd85496-7309-499f-b8f4-7f7889bfa4c8'),
	(6,4,2,'home',NULL,1,'2022-05-20 06:11:16','2022-05-20 06:11:16','3f9f4447-9710-49f2-86cb-28c20d257dc8'),
	(7,5,1,'home',NULL,1,'2022-05-20 06:11:25','2022-05-20 06:11:25','6fdd7ba0-7cda-40d5-a228-b4b4df7b0603'),
	(8,5,2,'home',NULL,1,'2022-05-20 06:11:25','2022-05-20 06:11:25','38dccf90-7590-461e-991f-19d6514ba6c8'),
	(11,7,1,NULL,NULL,1,'2022-05-20 06:11:32','2022-05-20 06:11:32','85d89358-a827-4ea3-bbf8-4eb976254861'),
	(12,7,2,NULL,NULL,1,'2022-05-20 06:11:32','2022-05-20 06:11:32','431ddeb3-237f-40dd-9055-382494aeddf8'),
	(13,8,1,NULL,NULL,1,'2022-05-20 06:11:35','2022-05-20 06:11:35','f9de196b-f332-4f62-a136-34ec584992b2'),
	(14,8,2,NULL,NULL,1,'2022-05-20 06:11:35','2022-05-20 06:11:35','09f9fc67-6032-4369-b3c2-aee509decb81'),
	(15,9,1,NULL,NULL,1,'2022-05-20 06:11:36','2022-05-20 06:11:36','2994003c-ea19-4d51-82a9-11c257da7e09'),
	(16,9,2,NULL,NULL,1,'2022-05-20 06:11:36','2022-05-20 06:11:36','baa36451-d616-43a6-9740-f30a6dfb71cc'),
	(17,10,1,NULL,NULL,1,'2022-05-20 06:11:36','2022-05-20 06:11:36','1eb4d68f-73a4-4b58-a530-9860d88e86c3'),
	(18,10,2,NULL,NULL,1,'2022-05-20 06:11:36','2022-05-20 06:11:36','2de777c2-1197-49a1-b418-59f9cb105e46'),
	(19,11,1,NULL,NULL,1,'2022-05-20 06:11:37','2022-05-20 06:11:37','c615e5f7-af16-43d1-a9df-f0cc08eadfab'),
	(20,11,2,NULL,NULL,1,'2022-05-20 06:11:37','2022-05-20 06:11:37','d8e11f88-784f-487b-a825-6ae12f854359'),
	(21,12,1,NULL,NULL,1,'2022-05-20 06:11:38','2022-05-20 06:11:38','5cc6eab1-76a9-4db0-9d23-198dad8fef7e'),
	(22,12,2,NULL,NULL,1,'2022-05-20 06:11:38','2022-05-20 06:11:38','383d0173-edce-47b0-a1e4-8ff120561bc8'),
	(23,13,1,NULL,NULL,1,'2022-05-20 06:11:38','2022-05-20 06:11:38','3c17a28f-ba91-4b43-a6ea-c60ee3eb1c8d'),
	(24,13,2,NULL,NULL,1,'2022-05-20 06:11:38','2022-05-20 06:11:38','f814843b-cdaf-492c-8d86-ff386827123a'),
	(25,14,1,NULL,NULL,1,'2022-05-20 06:11:39','2022-05-20 06:11:39','af496658-0f76-4743-9238-086c4d4126ed'),
	(26,14,2,NULL,NULL,1,'2022-05-20 06:11:39','2022-05-20 06:11:39','d9686e7c-a03d-4f61-9b73-68a4de420292'),
	(27,15,1,NULL,NULL,1,'2022-05-20 06:11:39','2022-05-20 06:11:39','9384a192-0fbf-4524-918e-1b16f1c2484f'),
	(28,15,2,NULL,NULL,1,'2022-05-20 06:11:39','2022-05-20 06:11:39','917f9328-f775-41f1-875f-d1cd0686c2f0'),
	(33,18,1,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','05642044-150c-4d2e-997c-ec94e255f03c'),
	(34,18,2,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','48d42521-88c6-4072-bb9d-36631d14a468'),
	(35,19,1,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','66a59cd5-5b24-4221-b36b-9787ee9e00fd'),
	(36,19,2,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','2bbbf92f-89a6-4f78-8114-ee8f5042c1a0'),
	(37,20,1,'home',NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','71ade00f-cea4-48de-ab46-6fe43c0ff043'),
	(38,20,2,'home',NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','1c7fe9f0-1ac7-496f-baec-236cbcb8dda3'),
	(39,21,1,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','bdad5a05-c0e5-4d5e-b7ef-d2cd51d81815'),
	(40,21,2,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','1ab606e0-178c-448a-bcb1-9e5ab68061fc'),
	(41,22,1,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','2f3ddd7b-61b9-404c-8a03-b9389e2ea664'),
	(42,22,2,NULL,NULL,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','0aea9f33-5db9-48fd-a1b8-ae4d7995815c'),
	(43,23,1,'home',NULL,1,'2022-05-20 06:11:45','2022-05-20 06:11:45','3865eb06-f0c8-4f21-a84e-61542f29f79e'),
	(44,23,2,'home',NULL,1,'2022-05-20 06:11:45','2022-05-20 06:11:45','db7bf1f8-fb0b-413a-9bc4-4755ab6061c7');

/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `entries`;

CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iaumihgvzgbvdlgleashydebbkanlhcewcep` (`postDate`),
  KEY `idx_tiuzwqjifmxyzpjxuyzcvmzypzbgpcbeltjq` (`expiryDate`),
  KEY `idx_jwaitgzshizvhcvtsjqajguhzxdivtrzizah` (`authorId`),
  KEY `idx_ytcqiwhaxsfeubennmvgsmiuqujalfouindi` (`sectionId`),
  KEY `idx_mnedwduygmvjxwjcxczkiyfanegblrhywshp` (`typeId`),
  KEY `fk_jykkjzdpgkzxyshvgecjbxecehtjqkmogyyj` (`parentId`),
  CONSTRAINT `fk_ertdfcvmqiiisasowpazunywyvdehzkbekfx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hoqwbzimkdrffntykgzcvhjisxzqykvzrklr` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jmqvtmovnpamzevnsxlglqgguicnnwkvkcqw` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jtpgwpdoytctcrflcifkfjmbeepufxnhkipa` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jykkjzdpgkzxyshvgecjbxecehtjqkmogyyj` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;

INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`)
VALUES
	(2,1,NULL,1,NULL,'2022-05-20 06:08:00',NULL,NULL,'2022-05-20 06:08:07','2022-05-20 06:08:07'),
	(3,1,NULL,1,NULL,'2022-05-20 06:08:00',NULL,NULL,'2022-05-20 06:08:07','2022-05-20 06:08:07'),
	(4,1,NULL,1,NULL,'2022-05-20 06:08:00',NULL,NULL,'2022-05-20 06:11:16','2022-05-20 06:11:16'),
	(5,1,NULL,1,NULL,'2022-05-20 06:08:00',NULL,NULL,'2022-05-20 06:11:25','2022-05-20 06:11:25'),
	(20,1,NULL,1,NULL,'2022-05-20 06:08:00',NULL,NULL,'2022-05-20 06:11:40','2022-05-20 06:11:40'),
	(23,1,NULL,1,NULL,'2022-05-20 06:08:00',NULL,NULL,'2022-05-20 06:11:45','2022-05-20 06:11:45');

/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump entrytypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `entrytypes`;

CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hjeoaqyuwsyqdfpmznnzebsqmjkhdldnlvjr` (`name`,`sectionId`),
  KEY `idx_zjzjtjcpbuematzqjbnnctypbmzsijlxnqyr` (`handle`,`sectionId`),
  KEY `idx_ypzoneorgormotxlbvbrktkwbwxebwkqksic` (`sectionId`),
  KEY `idx_zvwauxlbnphxxphnbidwacvxuiuvlqspenpm` (`fieldLayoutId`),
  KEY `idx_odjqzvtuwmvjwljdbqqrukzysgrfpymiqsrb` (`dateDeleted`),
  CONSTRAINT `fk_hmtubxyslrnzqahendoqezkjbnuawdbaoitd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yodedpbifgveblsmdicypxgdgxzgdtqkgewf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;

INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleTranslationMethod`, `titleTranslationKeyFormat`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,1,'Home','home',0,'site',NULL,'{section.name|raw}',1,'2022-05-20 06:08:07','2022-05-20 06:08:07',NULL,'bee5aa4a-febf-4a05-8909-1fc9ffa82280');

/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldgroups`;

CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_asoznjbtfzgsaycwctrkaoqbctannmtfelvv` (`name`),
  KEY `idx_fqgrsgbqyrhldjkkjclzzhdcpdgpqqnflsfj` (`dateDeleted`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;

INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,'Common','2022-05-20 05:57:30','2022-05-20 05:57:30',NULL,'8bdcfa7c-982f-47df-bd2e-bf48e43de9d6');

/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump fieldlayoutfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldlayoutfields`;

CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_plvcyjadysrnjderxkkwtqhenedawzxsgnud` (`layoutId`,`fieldId`),
  KEY `idx_dapteegkzdfcwazsfmgkzthnglutdwriowam` (`sortOrder`),
  KEY `idx_yjgbjbwiohcrljfvqkjgojrldzpgffezmywo` (`tabId`),
  KEY `idx_ayuyjshbkfkpktkcvppljpxrlrktmcshxhii` (`fieldId`),
  CONSTRAINT `fk_gjobbgtkbgvjykqbmbacsireqxhlhtarhifq` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kdgjughgqxvnvdbpiokpnalyvuhsrkpfiqys` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mxoqfkhdirppnntzolfisbwjxqsibxxcsrdz` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;

INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(3,2,3,2,0,0,'2022-05-20 06:10:01','2022-05-20 06:10:01','9b65d563-9c5a-411d-8188-4c8322ae4f30'),
	(4,2,3,3,0,1,'2022-05-20 06:10:01','2022-05-20 06:10:01','449be4a5-cce3-4b9d-b91d-d2d6a45210b6'),
	(5,1,4,1,0,1,'2022-05-20 06:11:25','2022-05-20 06:11:25','299845db-17ce-4d7f-8f1a-a0348b1c2e80');

/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump fieldlayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldlayouts`;

CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tfkrkuhybwvacssqluvrkhivsoymflhufmrc` (`dateDeleted`),
  KEY `idx_qzeoarspsxhkjpbljyvmeasdvramrzyonuwj` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;

INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,'craft\\elements\\Entry','2022-05-20 06:08:07','2022-05-20 06:08:07',NULL,'acc4a579-4344-4aa3-ad54-09334cc9e064'),
	(2,'craft\\elements\\MatrixBlock','2022-05-20 06:08:58','2022-05-20 06:08:58',NULL,'ede5261c-1913-465b-b257-05e1b481254b');

/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump fieldlayouttabs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldlayouttabs`;

CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emmvoadniujqxzahfpkskbmwyejfbrusyppv` (`sortOrder`),
  KEY `idx_rkqeycgnfnpigopdfhlxicqozzhniqsazhui` (`layoutId`),
  CONSTRAINT `fk_hscfisdglinhybdvaobqfwkythtogyfuwski` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;

INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `settings`, `elements`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(3,2,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"c2a9c171-0427-412f-abfd-5566557c3b38\",\"fieldUid\":\"901835fb-15bb-4917-bdd8-0e96dc0100d2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1f33852f-c681-4d03-9a5c-89ece64afa13\",\"fieldUid\":\"beaf3e23-368f-4935-9328-40606809d9bc\"}]',1,'2022-05-20 06:10:01','2022-05-20 06:10:01','b7658fb6-aede-4794-a4ac-b2861f6ab271'),
	(4,1,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"404fa88b-1fb0-4098-b26f-4e9d8a50e596\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"f401cab6-a5be-4e39-aaf3-6e4f41cd1378\",\"fieldUid\":\"6f88735f-d41c-4e41-9689-c5bacd8289fc\"}]',1,'2022-05-20 06:11:25','2022-05-20 06:11:25','09f46091-a666-42e3-8e51-b2c79fcd3e9c');

/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fields`;

CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nwxnzmjjojjuegxpcuxeobqyvssgvkrlcdlf` (`handle`,`context`),
  KEY `idx_dznaonliijtipfvotdksnzlyvnggbaxilozd` (`groupId`),
  KEY `idx_xbknqjnrfpvkqufzoftbgvotcopykedfgbcx` (`context`),
  CONSTRAINT `fk_mumvizhjwouubxihbpalkvlplqgaejuoyxuq` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;

INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `columnSuffix`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'Parameter','parameter','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_parameter}}\",\"maxBlocks\":null,\"minBlocks\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"siteGroup\"}','2022-05-20 06:08:58','2022-05-20 06:10:01','6f88735f-d41c-4e41-9689-c5bacd8289fc'),
	(2,NULL,'Parameter-Name','parameterName','matrixBlockType:d0409d96-4553-4fc3-b667-ac81a4f2d218','awrtisyp',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-05-20 06:08:58','2022-05-20 06:08:58','901835fb-15bb-4917-bdd8-0e96dc0100d2'),
	(3,NULL,'Parameter-Value','parameterValue','matrixBlockType:d0409d96-4553-4fc3-b667-ac81a4f2d218','jwemkcci',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-05-20 06:08:58','2022-05-20 06:08:58','beaf3e23-368f-4935-9328-40606809d9bc');

/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump globalsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `globalsets`;

CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fbmnkslzrhyhljwmivetaayivmyiyixulbrs` (`name`),
  KEY `idx_ixxussdulcjvchxbvhxxpzwtbfasjmcfsdfm` (`handle`),
  KEY `idx_hzupbocwozgxipkpncusnykjeozozcxccpsm` (`fieldLayoutId`),
  KEY `idx_ashhxqqwahiypvtlpujfuwokzuefjftenvht` (`sortOrder`),
  CONSTRAINT `fk_aelqgppymiobresjhnsreknsziwcmqyvswju` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yifajwzpdzzgwkxvuhbvvqiylaaeqnhzsxhn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump gqlschemas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gqlschemas`;

CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump gqltokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gqltokens`;

CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_buxnuadoidiwdrukslyicqxbimlvfvdbdleq` (`accessToken`),
  UNIQUE KEY `idx_ygkbjavanbhsjupltdndqjobspkqqnncqmpl` (`name`),
  KEY `fk_iszlmoiqflgbaftcicbddcbmugnevnnjnbaj` (`schemaId`),
  CONSTRAINT `fk_iszlmoiqflgbaftcicbddcbmugnevnnjnbaj` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump imagetransformindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `imagetransformindex`;

CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hhjcwfiyunlaqzfjaubhmzfzsbftgspmjhwr` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump imagetransforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `imagetransforms`;

CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_orvprefndroznddttcvbkvbvvxtikdposjpz` (`name`),
  KEY `idx_cmkpfrqploiveuztugjijsqwibkzqlidychz` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info`;

CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;

INSERT INTO `info` (`id`, `version`, `schemaVersion`, `maintenance`, `configVersion`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'4.0.2','4.0.0.9',0,'joojpyylewle','3@sdppgmttzo','2022-05-20 05:57:30','2022-05-20 06:11:25','72263f7f-c670-4b78-8ab0-f1c01bf59972');

/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump matrixblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixblocks`;

CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_forgpusfuabhdvwxmguhwgmcplxxljtvazux` (`primaryOwnerId`),
  KEY `idx_jwbwdcknwmngjspmmzrevubbesrinogwqgfr` (`fieldId`),
  KEY `idx_vtafiotdurlroiradfbqtjbvbbmlmxrspvpm` (`typeId`),
  CONSTRAINT `fk_gwyivxrwttfhsarcqykzlpvvnxandaoabqcr` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_itpckjxowxbfhrzznlnasfdyacsejsszjpas` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xgmebvkwhtfcaabspzrredqeepmhoisnpxzb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xmrbtyyxxlbwwxfmykxsbuapgsceskjmhzkc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;

INSERT INTO `matrixblocks` (`id`, `primaryOwnerId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`)
VALUES
	(18,2,1,1,NULL,'2022-05-20 06:11:40','2022-05-20 06:11:40'),
	(19,2,1,1,NULL,'2022-05-20 06:11:40','2022-05-20 06:11:40'),
	(21,20,1,1,NULL,'2022-05-20 06:11:40','2022-05-20 06:11:40'),
	(22,20,1,1,NULL,'2022-05-20 06:11:40','2022-05-20 06:11:40');

/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump matrixblocks_owners
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixblocks_owners`;

CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_ryvpuikfqcrhurvtmvqjltiquamfianocuxr` (`ownerId`),
  CONSTRAINT `fk_ryvpuikfqcrhurvtmvqjltiquamfianocuxr` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vnihrubycxlfnzfrajlvtfwiropiceaxntzg` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;

INSERT INTO `matrixblocks_owners` (`blockId`, `ownerId`, `sortOrder`)
VALUES
	(18,2,1),
	(19,2,2),
	(21,20,1),
	(21,23,1),
	(22,20,2),
	(22,23,2);

/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump matrixblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixblocktypes`;

CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eopqgfvbaypuyzkeihrlmsnifrbpiaotgfjp` (`name`,`fieldId`),
  KEY `idx_nejgjaafuauqzcazulyhjqgijitldskbepnd` (`handle`,`fieldId`),
  KEY `idx_zcscmlyfbyqvjhqzruyzfptuczyjogdouwnc` (`fieldId`),
  KEY `idx_lmqfxuogtyhkvsjmehdzldlvcgujbgpcgdxk` (`fieldLayoutId`),
  CONSTRAINT `fk_loruommslwrkbqsxhgfjhoiclgsvakuzzpzj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uqbohsoopglbelqnargidhidennrosxzuuop` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;

INSERT INTO `matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,2,'Parameter','parameter',1,'2022-05-20 06:08:58','2022-05-20 06:08:58','d0409d96-4553-4fc3-b667-ac81a4f2d218');

/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump matrixcontent_parameter
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixcontent_parameter`;

CREATE TABLE `matrixcontent_parameter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_parameter_parameterName_awrtisyp` text DEFAULT NULL,
  `field_parameter_parameterValue_jwemkcci` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jaurbksxihggfgldqujxyekbqlimcrwoziqi` (`elementId`,`siteId`),
  KEY `fk_lwdtjxzqkochxllpcuukbrukxjydekspkwrv` (`siteId`),
  CONSTRAINT `fk_lwdtjxzqkochxllpcuukbrukxjydekspkwrv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qkyabdsqfkqjioilcqkudbscqehrgchgzyeh` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixcontent_parameter` WRITE;
/*!40000 ALTER TABLE `matrixcontent_parameter` DISABLE KEYS */;

INSERT INTO `matrixcontent_parameter` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_parameter_parameterName_awrtisyp`, `field_parameter_parameterValue_jwemkcci`)
VALUES
	(1,7,1,'2022-05-20 06:11:32','2022-05-20 06:11:32','12554a74-600c-42a9-add9-8608c076ad3a',NULL,NULL),
	(2,7,2,'2022-05-20 06:11:32','2022-05-20 06:11:32','b6e3ec44-44b4-4488-8908-9e7d5856cde9',NULL,NULL),
	(3,8,1,'2022-05-20 06:11:35','2022-05-20 06:11:35','12fcf7f3-324e-45a9-a53e-243284298ceb','p1',NULL),
	(4,8,2,'2022-05-20 06:11:35','2022-05-20 06:11:35','b5a7999c-df9a-4e8c-b48f-22e4374b4f9e','p1',NULL),
	(5,9,1,'2022-05-20 06:11:36','2022-05-20 06:11:36','37c42722-d5d4-4bf6-b2d0-11bd30935d73','p1','v1'),
	(6,9,2,'2022-05-20 06:11:36','2022-05-20 06:11:36','158e963f-1967-403b-ba74-ecfff8ed909b','p1','v1'),
	(7,10,1,'2022-05-20 06:11:36','2022-05-20 06:11:36','d6fc5a34-f181-4b80-bb03-1e1a2a225f16','p1','v1'),
	(8,10,2,'2022-05-20 06:11:36','2022-05-20 06:11:36','1736e072-c118-4b4b-b01b-7506fbc3b9d7','p1','v1'),
	(9,11,1,'2022-05-20 06:11:37','2022-05-20 06:11:37','0c1e8f48-75b8-44f7-9ffb-e27329225b57',NULL,NULL),
	(10,11,2,'2022-05-20 06:11:37','2022-05-20 06:11:37','5abf9e63-534e-4f25-b412-7ee08191b51c',NULL,NULL),
	(11,12,1,'2022-05-20 06:11:38','2022-05-20 06:11:38','aa836d1f-ea87-4d17-90c8-dde0a81eeb07','p1','v1'),
	(12,12,2,'2022-05-20 06:11:38','2022-05-20 06:11:38','e84658ef-b15a-4ece-ad23-98bae24c17a0','p1','v1'),
	(13,13,1,'2022-05-20 06:11:38','2022-05-20 06:11:38','794bd309-d209-40b1-8669-7223e07bc332','p2',NULL),
	(14,13,2,'2022-05-20 06:11:38','2022-05-20 06:11:38','13cc1593-37fa-4ca4-91c5-ad3e6821ce02','p2',NULL),
	(15,14,1,'2022-05-20 06:11:39','2022-05-20 06:11:39','dc5afe52-0dff-44aa-a3c6-a06671139a50','p1','v1'),
	(16,14,2,'2022-05-20 06:11:39','2022-05-20 06:11:39','0f6e48c7-b98a-49db-bcf5-aa46346be5fb','p1','v1'),
	(17,15,1,'2022-05-20 06:11:39','2022-05-20 06:11:39','952630f3-917a-46d8-a03a-ba3b74aeb4e8','p2','v2'),
	(18,15,2,'2022-05-20 06:11:39','2022-05-20 06:11:39','7c473e36-2eff-4e41-81ff-56241fa07bd0','p2','v2'),
	(23,18,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','9d5abce8-d778-4ce5-8258-55ce70a556e4','p1','v1'),
	(24,18,2,'2022-05-20 06:11:40','2022-05-20 06:11:40','00db713e-dee0-4814-a4a2-3b8e8a67225b','p1','v1'),
	(25,19,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','e6c465a6-8d12-43bb-a27e-c52404c268d6','p2','v2'),
	(26,19,2,'2022-05-20 06:11:40','2022-05-20 06:11:40','4d9dd40d-ea07-402d-a2f3-77ac9ac40393','p2','v2'),
	(27,21,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','7151862e-0422-40db-b030-3d2349f1625e','p1','v1'),
	(28,21,2,'2022-05-20 06:11:40','2022-05-20 06:11:40','635c2c4c-c192-4536-b918-5f4249931ae5','p1','v1'),
	(29,22,1,'2022-05-20 06:11:40','2022-05-20 06:11:40','31fa0a5d-c040-4bbe-ae53-59056a8cbee7','p2','v2'),
	(30,22,2,'2022-05-20 06:11:40','2022-05-20 06:11:40','8f74e21a-35f5-4d3b-b462-19b1a9691479','p2','v2');

/*!40000 ALTER TABLE `matrixcontent_parameter` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lxnjpirgkmxypgfrzhkgzwuoiijhgwkxaous` (`track`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `track`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'craft','Install','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','e3839566-dd5c-4a1b-bd16-b87d5d6ac68a'),
	(2,'craft','m210121_145800_asset_indexing_changes','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','b235c9d1-97b0-4aed-9e78-a1941053ba0b'),
	(3,'craft','m210624_222934_drop_deprecated_tables','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','4f127450-2aaa-4916-bf60-db5a65139ace'),
	(4,'craft','m210724_180756_rename_source_cols','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','0afc021b-4963-4a96-90f3-da75b7f0e0b0'),
	(5,'craft','m210809_124211_remove_superfluous_uids','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','b853cc89-f657-499c-ae13-f946734a5a15'),
	(6,'craft','m210817_014201_universal_users','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','4caa11b1-fa6e-45b4-9c1c-a16dd9acb65e'),
	(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','278e0e3a-05eb-482d-979f-54c0c232bb46'),
	(8,'craft','m211115_135500_image_transformers','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','5f38b64e-f72a-4286-9dea-7d0538866ec6'),
	(9,'craft','m211201_131000_filesystems','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','2a46c148-e366-4e05-ba6a-d1e9fb28be9b'),
	(10,'craft','m220103_043103_tab_conditions','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','15d14787-2462-4318-845f-7e61fa10201b'),
	(11,'craft','m220104_003433_asset_alt_text','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','f55eab48-8ba2-42ff-a4a6-b0d572260762'),
	(12,'craft','m220123_213619_update_permissions','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','270fbbb1-56be-4deb-85e8-b20f4012af5e'),
	(13,'craft','m220126_003432_addresses','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','010dca08-ff61-46e7-bbb6-9e5560e6527f'),
	(14,'craft','m220209_095604_add_indexes','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','6e6f72b1-7ba1-45f1-92e8-b9b8a6bcb61a'),
	(15,'craft','m220213_015220_matrixblocks_owners_table','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','e3facada-4697-47ba-aaff-cceeb6aa5a7e'),
	(16,'craft','m220214_000000_truncate_sessions','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','04d85285-eeb1-48ff-8000-df27ba38e795'),
	(17,'craft','m220222_122159_full_names','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','344d41f2-27f4-4763-b855-f16dd7987ca6'),
	(18,'craft','m220223_180559_nullable_address_owner','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','92c881df-b38c-4743-bd77-a1f636dd1da0'),
	(19,'craft','m220225_165000_transform_filesystems','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','b70e873f-e8d7-4572-ae7b-af86c1dd9c3f'),
	(20,'craft','m220309_152006_rename_field_layout_elements','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','7659e719-19db-4aa9-9bee-5014ac1d5bf0'),
	(21,'craft','m220314_211928_field_layout_element_uids','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','858f5d71-5ffa-45a7-9774-8d028597d85b'),
	(22,'craft','m220316_123800_transform_fs_subpath','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','2d18db50-d947-42b5-a610-ad4a4ddff5c9'),
	(23,'craft','m220317_174250_release_all_jobs','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','429836b4-16be-41f9-8385-3950254debe7'),
	(24,'craft','m220330_150000_add_site_gql_schema_components','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','b34f7b13-3ad2-4aa0-8796-f8b5b4ebcba4'),
	(25,'craft','m220413_024536_site_enabled_string','2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 05:57:31','f8e4f11b-5aa7-487d-a4d9-9cfd73c87725');

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `plugins`;

CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bintnkpbmgaijktycdfqlzcerbkrknrlehxr` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump projectconfig
# ------------------------------------------------------------

DROP TABLE IF EXISTS `projectconfig`;

CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;

INSERT INTO `projectconfig` (`path`, `value`)
VALUES
	('dateModified','1653027085'),
	('email.fromEmail','\"andres@voan.ch\"'),
	('email.fromName','\"PruneRevisionsMatrix\"'),
	('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.autocapitalize','true'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.autocomplete','false'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.autocorrect','true'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.class','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.disabled','false'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.id','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.instructions','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.label','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.max','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.min','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.name','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.orientation','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.placeholder','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.readonly','false'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.requirable','false'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.size','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.step','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.tip','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.title','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.uid','\"404fa88b-1fb0-4098-b26f-4e9d8a50e596\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.warning','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.0.width','100'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.fieldUid','\"6f88735f-d41c-4e41-9689-c5bacd8289fc\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.instructions','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.label','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.required','false'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.tip','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.uid','\"f401cab6-a5be-4e39-aaf3-6e4f41cd1378\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.warning','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.elements.1.width','100'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.name','\"Content\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.fieldLayouts.acc4a579-4344-4aa3-ad54-09334cc9e064.tabs.0.uid','\"09f46091-a666-42e3-8e51-b2c79fcd3e9c\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.handle','\"home\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.hasTitleField','false'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.name','\"Home\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.section','\"0c18c298-5b23-4595-87b9-080cf00b6123\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.sortOrder','1'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.titleFormat','\"{section.name|raw}\"'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.titleTranslationKeyFormat','null'),
	('entryTypes.bee5aa4a-febf-4a05-8909-1fc9ffa82280.titleTranslationMethod','\"site\"'),
	('fieldGroups.8bdcfa7c-982f-47df-bd2e-bf48e43de9d6.name','\"Common\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.columnSuffix','null'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.contentColumnType','\"string\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.fieldGroup','\"8bdcfa7c-982f-47df-bd2e-bf48e43de9d6\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.handle','\"parameter\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.instructions','null'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.name','\"Parameter\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.searchable','false'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.settings.contentTable','\"{{%matrixcontent_parameter}}\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.settings.maxBlocks','null'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.settings.minBlocks','null'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.settings.propagationKeyFormat','null'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.settings.propagationMethod','\"siteGroup\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.translationKeyFormat','null'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.translationMethod','\"site\"'),
	('fields.6f88735f-d41c-4e41-9689-c5bacd8289fc.type','\"craft\\\\fields\\\\Matrix\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.field','\"6f88735f-d41c-4e41-9689-c5bacd8289fc\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.fieldUid','\"901835fb-15bb-4917-bdd8-0e96dc0100d2\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.uid','\"c2a9c171-0427-412f-abfd-5566557c3b38\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.fieldUid','\"beaf3e23-368f-4935-9328-40606809d9bc\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.uid','\"1f33852f-c681-4d03-9a5c-89ece64afa13\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fieldLayouts.ede5261c-1913-465b-b257-05e1b481254b.tabs.0.uid','\"b7658fb6-aede-4794-a4ac-b2861f6ab271\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.columnSuffix','\"awrtisyp\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.contentColumnType','\"text\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.fieldGroup','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.handle','\"parameterName\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.instructions','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.name','\"Parameter-Name\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.searchable','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.byteLimit','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.charLimit','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.code','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.columnType','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.initialRows','4'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.multiline','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.placeholder','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.translationKeyFormat','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.translationMethod','\"none\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.901835fb-15bb-4917-bdd8-0e96dc0100d2.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.columnSuffix','\"jwemkcci\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.contentColumnType','\"text\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.fieldGroup','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.handle','\"parameterValue\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.instructions','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.name','\"Parameter-Value\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.searchable','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.byteLimit','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.charLimit','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.code','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.columnType','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.initialRows','4'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.multiline','false'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.placeholder','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.translationKeyFormat','null'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.translationMethod','\"none\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.fields.beaf3e23-368f-4935-9328-40606809d9bc.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.handle','\"parameter\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.name','\"Parameter\"'),
	('matrixBlockTypes.d0409d96-4553-4fc3-b667-ac81a4f2d218.sortOrder','1'),
	('meta.__names__.0c18c298-5b23-4595-87b9-080cf00b6123','\"Home\"'),
	('meta.__names__.6f88735f-d41c-4e41-9689-c5bacd8289fc','\"Parameter\"'),
	('meta.__names__.8bdcfa7c-982f-47df-bd2e-bf48e43de9d6','\"Common\"'),
	('meta.__names__.901835fb-15bb-4917-bdd8-0e96dc0100d2','\"Parameter-Name\"'),
	('meta.__names__.ae64ce60-e2e8-4297-a182-841461882e2e','\"PruneRevisionsMatrix\"'),
	('meta.__names__.beaf3e23-368f-4935-9328-40606809d9bc','\"Parameter-Value\"'),
	('meta.__names__.bee5aa4a-febf-4a05-8909-1fc9ffa82280','\"Home\"'),
	('meta.__names__.d0409d96-4553-4fc3-b667-ac81a4f2d218','\"Parameter\"'),
	('meta.__names__.d19e4e4d-f9ca-462a-8570-65e50bd96734','\"PruneRevisionsMatrixDE\"'),
	('meta.__names__.e51fd02a-a5c5-4291-88a6-e54f4e993744','\"PruneRevisionsMatrix\"'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.defaultPlacement','\"end\"'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.enableVersioning','true'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.handle','\"home\"'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.name','\"Home\"'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.propagationMethod','\"all\"'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.ae64ce60-e2e8-4297-a182-841461882e2e.enabledByDefault','true'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.ae64ce60-e2e8-4297-a182-841461882e2e.hasUrls','false'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.ae64ce60-e2e8-4297-a182-841461882e2e.template','null'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.ae64ce60-e2e8-4297-a182-841461882e2e.uriFormat','null'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.d19e4e4d-f9ca-462a-8570-65e50bd96734.enabledByDefault','true'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.d19e4e4d-f9ca-462a-8570-65e50bd96734.hasUrls','false'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.d19e4e4d-f9ca-462a-8570-65e50bd96734.template','null'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.siteSettings.d19e4e4d-f9ca-462a-8570-65e50bd96734.uriFormat','null'),
	('sections.0c18c298-5b23-4595-87b9-080cf00b6123.type','\"single\"'),
	('siteGroups.e51fd02a-a5c5-4291-88a6-e54f4e993744.name','\"PruneRevisionsMatrix\"'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.baseUrl','\"$PRIMARY_SITE_URL\"'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.handle','\"default\"'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.hasUrls','true'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.language','\"en-US\"'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.name','\"PruneRevisionsMatrix\"'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.primary','true'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.siteGroup','\"e51fd02a-a5c5-4291-88a6-e54f4e993744\"'),
	('sites.ae64ce60-e2e8-4297-a182-841461882e2e.sortOrder','1'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.baseUrl','\"@web/de/\"'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.enabled','\"1\"'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.handle','\"prunerevisionsmatrixde\"'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.hasUrls','true'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.language','\"de\"'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.name','\"PruneRevisionsMatrixDE\"'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.primary','false'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.siteGroup','\"e51fd02a-a5c5-4291-88a6-e54f4e993744\"'),
	('sites.d19e4e4d-f9ca-462a-8570-65e50bd96734.sortOrder','2'),
	('system.edition','\"solo\"'),
	('system.live','true'),
	('system.name','\"PruneRevisionsMatrix\"'),
	('system.schemaVersion','\"4.0.0.9\"'),
	('system.timeZone','\"America/Los_Angeles\"'),
	('users.allowPublicRegistration','false'),
	('users.defaultGroup','null'),
	('users.photoSubpath','null'),
	('users.photoVolumeUid','null'),
	('users.requireEmailVerification','true');

/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump queue
# ------------------------------------------------------------

DROP TABLE IF EXISTS `queue`;

CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qftepjbiutxyvocuajlkhuoyhfwtihmvzpbc` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_ixgvgexwctoojigvhqrnfdsyftowijuviaus` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `relations`;

CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mvrusmkedmkwpkamduolkeyqclgzrdaxhalw` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ixhpsjdzkrdrstqxjvjqomknufgpbvffdfzu` (`sourceId`),
  KEY `idx_dzsnopdozapawqgtnytyixjyaosrpqavtqfh` (`targetId`),
  KEY `idx_dytrabtcnbewbjvbrabrafttxdbsbluixuxm` (`sourceSiteId`),
  CONSTRAINT `fk_burilptmxrxvyrsspqfyzdisqercdmoprqrl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dhgtjdydbnuwfvjrggcakhmdkmxmfssjjtuv` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ftnhaqtrhzgdjwljribxybwkzovtmtrwizbc` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pcsydpienxgikvndrglpullvpbbzvzovnpvi` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump resourcepaths
# ------------------------------------------------------------

DROP TABLE IF EXISTS `resourcepaths`;

CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;

INSERT INTO `resourcepaths` (`hash`, `path`)
VALUES
	('117f8314','@craft/web/assets/sites/dist'),
	('1f8d8709','@craft/web/assets/fabric/dist'),
	('373fb01e','@craft/web/assets/garnish/dist'),
	('4268d335','@craft/web/assets/fieldsettings/dist'),
	('44010603','@craft/web/assets/iframeresizer/dist'),
	('4f2bf06c','@craft/web/assets/updateswidget/dist'),
	('4f600fb4','@craft/web/assets/d3/dist'),
	('555529fd','@craft/web/assets/cp/dist'),
	('57ae9a66','@craft/web/assets/focusvisible/dist'),
	('591d8bb5','@craft/web/assets/selectize/dist'),
	('5e083197','@craft/web/assets/tailwindreset/dist'),
	('6964275b','@craft/web/assets/axios/dist'),
	('7191b202','@craft/web/assets/recententries/dist'),
	('81498da1','@craft/web/assets/jqueryui/dist'),
	('8bae1db7','@bower/jquery/dist'),
	('8e4e025f','@craft/web/assets/elementresizedetector/dist'),
	('9f325b0a','@craft/web/assets/fileupload/dist'),
	('aed11dea','@craft/web/assets/dashboard/dist'),
	('b11bfe86','@craft/web/assets/matrixsettings/dist'),
	('ccb76c93','@craft/web/assets/vue/dist'),
	('ccef9ccc','@craft/web/assets/editsection/dist'),
	('d7923b21','@craft/web/assets/feed/dist'),
	('d897b4c8','@craft/web/assets/velocity/dist'),
	('dd00b67f','@craft/web/assets/jquerypayment/dist'),
	('dd53691d','@craft/web/assets/jquerytouchevents/dist'),
	('e15b6ca1','@craft/web/assets/picturefill/dist'),
	('e8870665','@craft/web/assets/craftsupport/dist'),
	('eae3d1a1','@craft/web/assets/xregexp/dist');

/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump revisions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `revisions`;

CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pkxgisszwlaybugvnnvmichhkktwifdahczq` (`canonicalId`,`num`),
  KEY `fk_axroapkksubpemhewqmabapwovpcemyxgjnr` (`creatorId`),
  CONSTRAINT `fk_axroapkksubpemhewqmabapwovpcemyxgjnr` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rhnohpyhhxueobutvxgrawldudgcqxvjqors` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;

INSERT INTO `revisions` (`id`, `canonicalId`, `creatorId`, `num`, `notes`)
VALUES
	(1,2,1,1,NULL),
	(2,2,1,2,NULL),
	(3,2,1,3,NULL),
	(4,2,1,4,'Applied “Draft 1”'),
	(5,18,1,1,NULL),
	(6,19,1,1,NULL),
	(7,2,1,5,'');

/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump searchindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `searchindex`;

CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_vdovaafptqxejyehmnlontulanstqiaebdel` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;

INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`)
VALUES
	(1,'username',0,1,' admin '),
	(1,'fullname',0,1,''),
	(1,'firstname',0,1,''),
	(1,'lastname',0,1,''),
	(1,'email',0,1,' andres voan ch '),
	(1,'slug',0,1,''),
	(2,'title',0,1,' home '),
	(2,'slug',0,2,' home '),
	(2,'slug',0,1,' home '),
	(2,'title',0,2,' home '),
	(18,'slug',0,1,''),
	(18,'slug',0,2,''),
	(19,'slug',0,1,''),
	(19,'slug',0,2,'');

/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump sections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sections`;

CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kacnvrnmftdjqwmvqvlquuvtguuqgkcotbql` (`handle`),
  KEY `idx_zigdrylusbfkorxcogvqsdgotqbdjxghldyn` (`name`),
  KEY `idx_tmspkayertidkbniyjlaqiroztehgnrfkcpq` (`structureId`),
  KEY `idx_divwslpalesgcahgtzmjafzntdprlpclxodo` (`dateDeleted`),
  CONSTRAINT `fk_phuqxdeuxbxnmuufagvlrojvikwplspoyrsr` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;

INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `defaultPlacement`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,NULL,'Home','home','single',1,'all','end',NULL,'2022-05-20 06:08:07','2022-05-20 06:08:07',NULL,'0c18c298-5b23-4595-87b9-080cf00b6123');

/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump sections_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sections_sites`;

CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unxdhkexcmehxselyakpthyyllwukxgrnuua` (`sectionId`,`siteId`),
  KEY `idx_xmaezvneajhergokyvxgmwbcbpghhstnfycc` (`siteId`),
  CONSTRAINT `fk_hnhawomlwzunfbjdgxeyfzfrnzsziscrvypn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mmbdtedcsbcwisjxtyvfztjmijtxezyjblrf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;

INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,0,NULL,NULL,1,'2022-05-20 06:08:07','2022-05-20 06:11:16','f80992e3-c007-4f9e-a33e-58e4e8e2a22e'),
	(2,1,2,0,NULL,NULL,1,'2022-05-20 06:11:16','2022-05-20 06:11:16','9e979143-c104-42ec-98c0-c7d7fbd3525f');

/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump sequences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sequences`;

CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sessions`;

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dgvgunfgnmsseutmszybgqifwtvavvjhrrdm` (`uid`),
  KEY `idx_ntxkpzgngrklyldeezevntxkntsfoqtndelk` (`token`),
  KEY `idx_kdddcirtfcrhwqqsbolxijiachlmhrymjpce` (`dateUpdated`),
  KEY `idx_vluedpyticqshcyzfpksflwzhxcxacweynrv` (`userId`),
  CONSTRAINT `fk_sejzduursmoydahnbpbgtcgkrswysrnmgdry` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;

INSERT INTO `sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'ks9Tyy1B_eYs1d71oTDMg2K4VaJKWPUeKY6z_oRii_7zZUwYALzs5JekNepV5DNKiOO5BVR_KSZ3yAHmdwYi36XhRkkuX84XoGrJ','2022-05-20 06:07:41','2022-05-20 06:11:47','b3ef92f8-7f1e-4a36-8ef3-f6c182529989');

/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump shunnedmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `shunnedmessages`;

CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jsiaiolxfxlunbsaiciuzlddkpwtptperdhw` (`userId`,`message`),
  CONSTRAINT `fk_vvzwdrfantlvtpszyesidumtkydspfwqvyzd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump sitegroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sitegroups`;

CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ytrxrgfbxewjhoqjdmkwfppeekjkvhwmsvwt` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;

INSERT INTO `sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,'PruneRevisionsMatrix','2022-05-20 05:57:30','2022-05-20 05:57:30',NULL,'e51fd02a-a5c5-4291-88a6-e54f4e993744');

/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sites`;

CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sffezfvebocasejzhxsdcgitkpebdjfmtknl` (`dateDeleted`),
  KEY `idx_cxhgkohhhhkerykhazuvpjnptogpbcreyclt` (`handle`),
  KEY `idx_ddzebtckkdbwfhjkhzyznryaycjodxwpjmig` (`sortOrder`),
  KEY `fk_kqtlrytdiqmkqodilwyauerjxwywlntkbxsv` (`groupId`),
  CONSTRAINT `fk_kqtlrytdiqmkqodilwyauerjxwywlntkbxsv` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;

INSERT INTO `sites` (`id`, `groupId`, `primary`, `enabled`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,1,'true','PruneRevisionsMatrix','default','en-US',1,'$PRIMARY_SITE_URL',1,'2022-05-20 05:57:30','2022-05-20 05:57:30',NULL,'ae64ce60-e2e8-4297-a182-841461882e2e'),
	(2,1,0,'1','PruneRevisionsMatrixDE','prunerevisionsmatrixde','de',1,'@web/de/',2,'2022-05-20 06:09:45','2022-05-20 06:09:45',NULL,'d19e4e4d-f9ca-462a-8570-65e50bd96734');

/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump structureelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `structureelements`;

CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kafwosflnntepnihjkfaukwcvcffxqzkeopv` (`structureId`,`elementId`),
  KEY `idx_exbntwtsjxdnzrsrnssvxcnpzdrgrarabfnw` (`root`),
  KEY `idx_pnliprujtyfylhqwssgnjycbdnvmtbebsbqs` (`lft`),
  KEY `idx_ghfnlwqbskkqhrkquishcipcemhwxnsvcqpc` (`rgt`),
  KEY `idx_oirgevrotedathvutibubgwtekvxtbcklrkf` (`level`),
  KEY `idx_avbxszrhfdvxdiqzgciingzmtneadzsbmspx` (`elementId`),
  CONSTRAINT `fk_ccfabikrqbnwjgfgsjigojtfxxsijurdrpdf` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cpnupuwvlaammiaacvwzdnlmgqbsgnxzutxs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `structures`;

CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lnybjhqxbjvinefzobqivbqthlowjmxbangr` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump systemmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `systemmessages`;

CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kdpiegntdoxbllzduednnibntahizwaavcfx` (`key`,`language`),
  KEY `idx_dqybkdfjjiuojvyywebgnrcvuhenthikfcce` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump taggroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `taggroups`;

CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hmzcapommawlvohltrklkmexxyedjsvvizqn` (`name`),
  KEY `idx_sgirazeqlxplkvcxibxyigzpinnlvrldkadp` (`handle`),
  KEY `idx_pvvacxnvixgicuwteyckblbcujeuqupakadu` (`dateDeleted`),
  KEY `fk_qbopwjjhyokaspxewiiaitjablxonvofwzrs` (`fieldLayoutId`),
  CONSTRAINT `fk_qbopwjjhyokaspxewiiaitjablxonvofwzrs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tags`;

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_twbqspohhzbtgnztugvzzbwjqdbwdcctroyb` (`groupId`),
  CONSTRAINT `fk_clebhdaziafzrymbfcaapzbshctkrxksrmkg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gaponnexwjlpppuiinqywpbzfhjrwxzdmmzh` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oezgzxdydtdklbbcmiqsqfvjnlusyioadbaz` (`token`),
  KEY `idx_nrajoldxxemaoggqqvuhqtihzacpfollzbhx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usergroups`;

CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vpkfibhoewaaaxzlecmjmvuqcsweuntlbczk` (`handle`),
  KEY `idx_ybwdxohzvcdmkjjpbofdekqrbikgjmkpyjmi` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump usergroups_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usergroups_users`;

CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kogtjmueynivcnywfrxmvsflokladhsqoygw` (`groupId`,`userId`),
  KEY `idx_stfqifenjkwfhpcazswaododwmttndsnsveo` (`userId`),
  CONSTRAINT `fk_jvwjwnxjodkfspmzcxgyqdgnxnfrcjrpbnyr` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rhpeqrairnswfaolshgalhviueofcjoooiju` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump userpermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpermissions`;

CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wcezamlvyyzovokrskkuscijmrphjqukproa` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump userpermissions_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpermissions_usergroups`;

CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lkpzraixodciuqdyurglhkwfwasculaoxvfz` (`permissionId`,`groupId`),
  KEY `idx_efzwdmmihngejfljqoubbrwbfitcvnjlkqry` (`groupId`),
  CONSTRAINT `fk_cnwilxnzevoqzvdhrzrjimlvlmdtlixlpzdm` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kowrkucjfzpolsvgflwtkgkojhyikwmacguh` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump userpermissions_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpermissions_users`;

CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qrtxpemkdqnmenznjdtyarqvsvdwdgfotgmy` (`permissionId`,`userId`),
  KEY `idx_yabwywefrmsmmcxkjfsgeysziunvpyeostjz` (`userId`),
  CONSTRAINT `fk_awbsffsiczbdbcpvvhsxpicyxommtynzfvjj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_woejytfqemjqbmhviyewzwkgdxhzfbwbczdr` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump userpreferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpreferences`;

CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_urxgiqsghxzbmjyfdteoygfbafxvtpwwfvga` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;

INSERT INTO `userpreferences` (`userId`, `preferences`)
VALUES
	(1,'{\"language\":\"en-US\"}');

/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gcmwnhpvegdskrbzgvygnqjdxbrzurvffiat` (`active`),
  KEY `idx_gkcnbjqqzjjgkhkmeoyocfpzjbstszshdaur` (`locked`),
  KEY `idx_yqhnhmkaivumkimlsrhxlfzfgdlenfndecsk` (`pending`),
  KEY `idx_igefaibjbotsaavrhfbnvcpqpplhyivrqnnp` (`suspended`),
  KEY `idx_riqqbaarteorshzdgptlqvhbkamuopatbfte` (`verificationCode`),
  KEY `idx_aqhmqcdxoomdnjaijehbsqedlybomupoqgtj` (`email`),
  KEY `idx_foxucvrwvfkqxqyjjkmpdpqsjdtfecmpsetk` (`username`),
  KEY `fk_bhrpxulootcoipavvpnsbrkallozdjyaqltd` (`photoId`),
  CONSTRAINT `fk_bhrpxulootcoipavvpnsbrkallozdjyaqltd` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xdulgsppjfcqlvdxulnqnemrqduqwfxauoob` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `photoId`, `active`, `pending`, `locked`, `suspended`, `admin`, `username`, `fullName`, `firstName`, `lastName`, `email`, `password`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`)
VALUES
	(1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'andres@voan.ch','$2y$13$F/3XtqtytmwaVwOTiHM6y.bZbndByXSeUZz.cFbuzKAsX/VRlKlsm','2022-05-20 06:07:41',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2022-05-20 05:57:31','2022-05-20 05:57:31','2022-05-20 06:07:42');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump volumefolders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `volumefolders`;

CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rniqhmnlnmbvwvkolfecpycdllgrjkarolza` (`name`,`parentId`,`volumeId`),
  KEY `idx_awbxchxdohumzkypwtqmstmzlcwbzcasjdgh` (`parentId`),
  KEY `idx_tugicyuizvbawpvoqkcxbcpzhbltbfnmywns` (`volumeId`),
  CONSTRAINT `fk_gxpznflrxcypzqtzqoilwjvacqtpqkasuewe` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hotaftodnwnrphrqpjfbqmncpzufvzrbvvve` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump volumes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `volumes`;

CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mwzjyiurazcwdzbhrbbixzxbxhyafydjsusc` (`name`),
  KEY `idx_mqftyykligksyuhegtrnnfnueesolmlqeylu` (`handle`),
  KEY `idx_lktrnqlarkconotwpppqfaxwijcyvslxhwjd` (`fieldLayoutId`),
  KEY `idx_ecibpsbmytfjxyqandpfsipwcwttllvtdfaj` (`dateDeleted`),
  CONSTRAINT `fk_nufqapgvjoccjwkvizgettmtskgoosnewhas` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabellen-Dump widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `widgets`;

CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bsqceertuanxpdaootbrxqgreuskpvocjobh` (`userId`),
  CONSTRAINT `fk_jjoltctxawmohokdlpkspgtwuesotpasmbvd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;

INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2022-05-20 06:07:42','2022-05-20 06:07:42','b44bf310-fbcc-4af3-8e35-2b236ecb42e4'),
	(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2022-05-20 06:07:42','2022-05-20 06:07:42','99690835-2d76-4ba4-821a-fe62c0f7f24c'),
	(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2022-05-20 06:07:42','2022-05-20 06:07:42','5704d582-07e1-4a39-8eb3-0a4b1df74ad1'),
	(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2022-05-20 06:07:42','2022-05-20 06:07:42','5b3782d3-0897-4d1a-b65d-91479a5c2d6a');

/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
